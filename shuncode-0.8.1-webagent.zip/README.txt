ShunCode 0.8.1 - reference sources for web_agent
================================================

Read 总表.md first: it lists all 23 items with their benefit, cost and
priority, plus 13 things NOT to change because web_agent already does them
better. 方案-*.md expand each item.

方法论优化.md is a different kind of document: instead of "web_agent is
missing X", it distills the recurring *approach* in ShunCode's source and
applies it to web_agent's own architecture. Most of its 8 proposals have no
direct ShunCode counterpart.

Scope: tunnel reachability, proxy support, startup failure codes, skill
import, terminal contract, stateless request identity.
Deliberately excluded: payment/licensing, and the external-MCP set already
delivered in shuncode-0.8.1-mcp-skills.zip.

original-typescript/
    The author's own TypeScript, shipped verbatim inside the installer.
    Type annotations and comments are intact. This is the better reference.

recovered-from-bundle/
    Sliced out of the shipped dist/extension.js. The logic is the author's
    and the names are real, but TypeScript types and most comments were
    erased by the compiler, and imports are not rewired. Read for behaviour,
    never execute as-is.

These are NOT a drop-in library. ShunCode is a VS Code fork; these files
import from a carrier web_agent does not have. Copy ideas and constants,
not files.

MANIFEST.json lists every entry with its sha256 and why it is here.
